IT 3203 Milestone #1 - Web Browsers Website

FILES: Six HTML pages, one style.css, and one original SVG image.

TO VIEW: Open index.html in your browser.

TO PUBLISH: Create a public GitHub repository (for example browser-history-project). Upload the contents of this folder to the repository root. In Settings > Pages, choose Deploy from a branch, main, /(root), and Save. Wait for GitHub to publish. Your URL should look like https://YOUR-USERNAME.github.io/browser-history-project/ . Replace YOUR-USERNAME with your actual GitHub username.

TO VALIDATE: Check each published HTML page at https://validator.w3.org/nu/ and fix any reported errors.

BEFORE SUBMISSION: Review all text, personalize the About Me page, verify links and source details, and test the live website. Submit the live URL and the ZIP.
